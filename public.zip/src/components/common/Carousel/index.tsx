import React, { useState, useEffect } from "react";
import LogoPic from "../../../assets/images/logo-4.svg";

const Carousel: React.FC = () => {
  const images = [LogoPic, LogoPic, LogoPic, LogoPic, LogoPic, LogoPic];

  const [currentImage, setCurrentImage] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImage((prevImage) => (prevImage + 1) % images.length);
    }, 3000);

    return () => clearInterval(interval);
  }, [images.length]);
  return (
    <div className="flex items-center justify-center">
      {images.map((image, index) => (
        <img
          key={index}
          src={image}
          alt={`Image ${index + 1}`}
          className={`mx-3 ${index !== currentImage ? "opacity-50" : ""}`}
        />
      ))}
    </div>
  );
};

export default Carousel;
